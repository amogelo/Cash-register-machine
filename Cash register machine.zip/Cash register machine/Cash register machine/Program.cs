﻿using System;
using System.Collections.Generic;

class Transaction
{
    public string Type { get; set; }
    public double Amount { get; set; }
    public DateTime Timestamp { get; set; }

    public Transaction(string type, double amount)
    {
        Type = type;
        Amount = amount;
        Timestamp = DateTime.Now;
    }

    public override string ToString()
    {
        return $"{Timestamp}: {Type} of {Amount}";
    }
}

class CashRegister
{
    private double balance;
    private List<Transaction> transactions;

    public CashRegister(double initialBalance)
    {
        balance = initialBalance;
        transactions = new List<Transaction>();
    }

    public double GetBalance()
    {
        return balance;
    }

    public void SellItem(string itemName, double price)
    {
        if (price > 0 && price <= balance)
        {
            balance -= price;
            transactions.Add(new Transaction($"Sold {itemName}", price));
            Console.WriteLine($"Sold {itemName} for {price}. Remaining balance: {balance}");
        }
        else
        {
            Console.WriteLine("Invalid price or insufficient balance.");
        }
    }

    public void SellAirtime(double amount)
    {
        if (amount > 0 && amount <= balance)
        {
            balance -= amount;
            transactions.Add(new Transaction("Sold airtime", amount));
            Console.WriteLine($"Sold airtime for {amount}. Remaining balance: {balance}");
        }
        else
        {
            Console.WriteLine("Invalid amount or insufficient balance.");
        }
    }

    public void SellElectricity(double amount)
    {
        if (amount > 0 && amount <= balance)
        {
            balance -= amount;
            transactions.Add(new Transaction("Sold electricity", amount));
            Console.WriteLine($"Sold electricity for {amount}. Remaining balance: {balance}");
        }
        else
        {
            Console.WriteLine("Invalid amount or insufficient balance.");
        }
    }

    public void ShowTransactionHistory()
    {
        Console.WriteLine("Transaction History:");
        foreach (Transaction transaction in transactions)
        {
            Console.WriteLine(transaction);
        }
    }
}

class Program
{
    static void Main()
    {
        CashRegister cashRegister = new CashRegister(1000);

        Console.WriteLine("Welcome to the Cash Register.");

        while (true)
        {
            Console.WriteLine("Select an option:");
            Console.WriteLine("1. Check Balance");
            Console.WriteLine("2. Sell Item");
            Console.WriteLine("3. Sell Airtime");
            Console.WriteLine("4. Sell Electricity");
            Console.WriteLine("5. Transaction History");
            Console.WriteLine("6. Exit");

            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.WriteLine($"Your balance is {cashRegister.GetBalance()}");
                    break;
                case 2:
                    Console.Write("Enter item name: ");
                    string itemName = Console.ReadLine();
                    Console.Write("Enter item price: ");
                    double itemPrice = double.Parse(Console.ReadLine());
                    cashRegister.SellItem(itemName, itemPrice);
                    break;
                case 3:
                    Console.Write("Enter airtime amount: ");
                    double airtimeAmount = double.Parse(Console.ReadLine());
                    cashRegister.SellAirtime(airtimeAmount);
                    break;
                case 4:
                    Console.Write("Enter electricity amount: ");
                    double electricityAmount = double.Parse(Console.ReadLine());
                    cashRegister.SellElectricity(electricityAmount);
                    break;
                case 5:
                    cashRegister.ShowTransactionHistory();
                    break;
                case 6:
                    Console.WriteLine("Thank you for using the Cash Register.");
                    return;
                default:
                    Console.WriteLine("Invalid option.");
                    break;
            }
        }
    }
}
